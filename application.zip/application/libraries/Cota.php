<?php

class Cota
{

 function __construct()
 {
   # code...
 }
 
 public $idcota;
 public $valor;
 public $dataCompra;
 public $dataFechamento;
 public $rendimento;
 public $conta_idconta;

 

}


?>