<?php

class Comissao
{

 function __construct()
 {
   # code...
 }
 
 public $idcomissao;
 public $valor;
 public $percentual;
 public $rendimento_idrendimento;
 

}


?>