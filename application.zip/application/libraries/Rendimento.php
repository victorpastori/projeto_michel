<?php

class Rendimento
{

 function __construct()
 {
   # code...
 }
 
 public $idrendimento;
 public $percentual;
 public $capital;
 public $valor;
 public $data;
 public $conta_idconta;
 public $tipo_rendimento_idtipo_rendimento;
 
 

}


?>