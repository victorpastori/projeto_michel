<?php

class Cliente
{

 function __construct()
 {
   # code...
 }
 
 public $idcliente;
 public $nome;
 public $email;
 public $cpf;
 public $usuario_idusuario;
 

}


?>