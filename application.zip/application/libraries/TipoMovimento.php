<?php

class TipoMovimento
{

 function __construct()
 {
   # code...
 	/*Tipos de movimento: 	1 -> Saque
 							2 -> Depósito
 							3 -> Retorno Investimento
 							4 -> Retorno Cota
 							5 -> Transferência (Previsão futura) */
 }
 
 public $idTipoMovimento;
 public $tipo;
 public $descricao;
 

}


?>