<?php

class ContaSaque
{

 function __construct()
 {
   # code...
 }

 public $idconta;
 public $agencia;
 public $conta;
 public $tipo;
 public $cliente_idcliente;
 public $banco_idbanco;

}


?>