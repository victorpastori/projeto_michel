<?php

class Usuario
{

 function __construct()
 {
   # code...
 }
 
 public $login;
 public $senha;
 public $tipo;
 

}


?>