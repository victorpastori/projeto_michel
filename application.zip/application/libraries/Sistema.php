<?php

class Sistema
{

 function __construct()
 {
   # code...
 }
 
 public $idsistema;
 public $valorAdmCota;
 public $valorAdmRendimento;
 public $diaInicialRendimento;
 public $conta_idconta;
 

}


?>