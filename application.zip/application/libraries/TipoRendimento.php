<?php

class TipoRendimento
{

 function __construct()
 {
   # code...
 	/* Tipo de rendimento: 	1 -> Rendimento mensal sobre saldo da conta(Saldo a receber e bloqueado não entram nessa conta)
 							2 -> Rendimento mensal sobre investimento(Depósito que tem X carência) 
 							3 -> Rendimento Cota */
 							
 }
 
 public $idTipoRendimento;
 public $tipo;
 public $descricao;

 

}


?>