<?php

class Conta
{

 function __construct()
 {
   # code...
 }
 
 public $idconta;
 public $saldo;
 public $saldoSaque;
 public $saldoBloqueado;
 public $cliente_idcliente;
 public $cliente_usuario_idusuario;
 

}


?>